package com.gestion.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionUsuariosBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
