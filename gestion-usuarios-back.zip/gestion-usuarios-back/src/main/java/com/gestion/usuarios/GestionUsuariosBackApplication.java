package com.gestion.usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionUsuariosBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionUsuariosBackApplication.class, args);
	}

}
